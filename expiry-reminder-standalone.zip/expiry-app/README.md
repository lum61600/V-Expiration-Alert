# 到期提醒 Expiry Reminder

商品到期提醒工具，Apple 極簡風格，單頁 React 應用。資料儲存在瀏覽器的
`localStorage`，不需要後端、不需要資料庫，打包後就是純靜態檔案。

## 本機開發

```bash
npm install
npm run dev
```

打開瀏覽器造訪終端機顯示的網址（預設 http://localhost:5173）。

## 打包成靜態檔案

```bash
npm run build
```

打包完成後，靜態檔案會輸出到 `dist/` 資料夾，裡面包含 `index.html`、
`assets/xxx.js`、`assets/xxx.css`。

## 部署到自己的伺服器

`dist/` 資料夾就是最終成品，是純靜態檔案，把整個資料夾內容丟到任何一種
靜態網站主機即可，例如：

- **Nginx / Apache**：把 `dist/` 內容複製到網站根目錄（例如
  `/var/www/expiry-app`），確保伺服器設定會把找不到的路徑導回
  `index.html`（single-page app 常見設定，避免重新整理時 404）。
- **Node 靜態伺服器（測試用）**：
  ```bash
  npm install -g serve
  serve dist -l 3000
  ```
- **Vercel / Netlify / Cloudflare Pages**：直接把整個資料夾拖進去部署，
  或指定 build 指令為 `npm run build`、輸出目錄為 `dist`。

## 資料儲存說明

- 所有商品、分類、篩選/排序設定都存在使用者瀏覽器的 `localStorage`，
  key 是 `expiry-reminder-data`。
- **這代表資料是「裝置 + 瀏覽器」層級的**：換一台電腦、換一個瀏覽器，
  或使用者清除瀏覽器資料，先前的紀錄就不會同步過去。
- 無痕模式下寫入可能被瀏覽器擋掉，程式已用 try/catch 處理，不會噴錯，
  但資料不會被保留。
- 如果之後想要跨裝置同步，需要另外接後端 API + 資料庫（例如把
  `loadStoredData` / 儲存那段 `useEffect` 換成打自己的 API），目前這版
  是最簡單、不需要任何後端的版本。

## 瀏覽器通知

「即將到期提醒」開關會呼叫瀏覽器原生 Notification API，第一次開啟時
會跳出瀏覽器的授權詢問視窗。這個授權是「使用者＋瀏覽器＋網域」三者綁
定的，換瀏覽器或換網域都需要重新授權一次。
